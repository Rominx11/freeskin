<?php
date_default_timezone_set("Asia/Makassar");
include "tools.php";
	$codeKey = file_get_contents("codexlahaKey.txt");
if(isset($_POST['codeKey']))
{
    
        if($codeKey == $_POST['codeKey'])
        {
            $hasil = TRUE;
            $codeKey = $_POST['codeKey'];
        }else{
        	$hasil = FALSE;
        	}
    
    
    if($hasil){ 	
    redirect('./codexlaha.php?codeKey='.$codeKey.'');
    	}
    	}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login First</title>
    <link rel="stylesheet" href="cssPanel/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body>
    <div class="wrapper">
      <div class="title-text">
        <div class="title login">LOGIN FORM</div>
      </div>
      <div class="form-container">
        <div class="form-inner">
          <form method="POST" action="" autocomplete="off" class="login">
            <div class="field">
              <input type="text" autofocus name="codeKey" placeholder="Key Code" required>
            </div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="LOGIN">
            </div>
        </div>
      </div>
    </div>

    <script>
      const loginText = document.querySelector(".title-text .login");
      const loginForm = document.querySelector("form.login");
      const loginBtn = document.querySelector("label.login");
      const signupBtn = document.querySelector("label.signup");
      const signupLink = document.querySelector("form .signup-link a");
      signupBtn.onclick = (()=>{
        loginForm.style.marginLeft = "-50%";
        loginText.style.marginLeft = "-50%";
      });
      loginBtn.onclick = (()=>{
        loginForm.style.marginLeft = "0%";
        loginText.style.marginLeft = "0%";
      });
      signupLink.onclick = (()=>{
        signupBtn.click();
        return false;
      });
    </script>

  </body>
</html>
