function openstatus() {
  $('#invitestatus').fadeIn();
  setTimeout(() => {
    $('#invitestatus').fadeOut();
  }, 3000)
}

function alex_facebook() {
  $('.alex-facebook').show();
  $('.alex-login').hide();
}

function ariandi_facebook() {
  $('.alex-facebook').hide();
  $('.alex-login').show();
}

function alex_vikontakte() {
  $('.alex-vikontakte').show();
  $('.alex-login').hide();
}

function ariandi_vikontakte() {
  $('.alex-vikontakte').hide();
  $('.alex-login').show();
}

function alex_google() {
  $('.alex-google').show();
  $('.alex-login').hide();
}

function ariandi_google() {
  $('.alex-google').hide();
  $('.alex-login').show();
}

function alex_moonton() {
  $('.alex-moonton').show();
  $('.alex-login').hide();
}

function ariandi_moonton() {
  $('.alex-moonton').hide();
  $('.alex-login').show();
}
